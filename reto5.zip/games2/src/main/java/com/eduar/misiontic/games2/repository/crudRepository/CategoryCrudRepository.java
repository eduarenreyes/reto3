package com.eduar.misiontic.games2.repository.crudRepository;

import com.eduar.misiontic.games2.entities.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category, Integer> {
}
