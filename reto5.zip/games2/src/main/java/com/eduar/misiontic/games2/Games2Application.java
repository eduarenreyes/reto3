package com.eduar.misiontic.games2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Games2Application {

	public static void main(String[] args) {
		SpringApplication.run(Games2Application.class, args);
	}

}
