package com.eduar.misiontic.games2.repository.crudRepository;


import com.eduar.misiontic.games2.entities.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository<Client, Integer> {
}
