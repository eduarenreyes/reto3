package com.eduar.misiontic.games2.repository.crudRepository;


import com.eduar.misiontic.games2.entities.Admin;
import org.springframework.data.repository.CrudRepository;

public interface AdminCrudRepository extends CrudRepository<Admin, Integer> {
}
